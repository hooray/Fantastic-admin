
/**
 * name: Fantastic-admin
 * homepage: https://hooray.gitee.io/fantastic-admin/
 */
    
import{r as o,o as e,s as a,i as d,w as n}from"./vendor.5d2d2ca8.js";const r={};r.render=function(r,t){const l=o("page-header"),f=o("ColorfulCard"),c=o("el-col"),u=o("el-row"),i=o("page-main");return e(),a("div",null,[d(l,{title:"多彩渐变卡片",content:"ColorfulCard"}),d(i,null,{default:n((()=>[d(u,{gutter:20},{default:n((()=>[d(c,{md:6},{default:n((()=>[d(f,{header:"开发文档",num:123,tip:"较上周上升50%",icon:"index-document"})])),_:1}),d(c,{md:6},{default:n((()=>[d(f,{"color-from":"#fbaaa2","color-to":"#fc5286",header:"基础组件",num:12323,tip:"较上周上升50%",icon:"index-component"})])),_:1}),d(c,{md:6},{default:n((()=>[d(f,{"color-from":"#ff763b","color-to":"#ffc480",header:"扩展组件",num:123,tip:"较上周上升50%",icon:"index-component"})])),_:1}),d(c,{md:6},{default:n((()=>[d(f,{"color-from":"#6a8eff","color-to":"#0e4cfd",header:"业务应用页面",num:123,tip:"较上周上升50%",icon:"index-page"})])),_:1})])),_:1})])),_:1})])};export{r as default};
