
/**
 * name: Fantastic-admin
 * homepage: https://hooray.gitee.io/fantastic-admin/
 */
    
import{n as e,q as a,r,o as l,s as o,i as t,w as d,A as u}from"./vendor.5d2d2ca8.js";const m={name:"ComponentExampleArea",props:{},data:()=>({area:["浙江省","杭州市","西湖区"],ruleForm:{area:[]},rules:{area:[{type:"array",required:!0,message:"请选择地区",trigger:"change"}]}}),created(){},mounted(){},methods:{submitForm(){this.$refs.ruleForm.validate((e=>{e&&alert("提交成功")}))}}};e("data-v-219cd1aa");const s=u("提交");a(),m.render=function(e,a,u,m,n,i){const c=r("page-header"),p=r("cascader-area"),f=r("page-main"),F=r("el-form-item"),_=r("el-button"),g=r("el-form");return l(),o("div",null,[t(c,{title:"省市区联动",content:"CascaderArea"}),t(f,null,{default:d((()=>[t(p,{modelValue:n.area,"onUpdate:modelValue":a[0]||(a[0]=e=>n.area=e)},null,8,["modelValue"])])),_:1}),t(f,{title:"表单验证"},{default:d((()=>[t(g,{ref:"ruleForm",model:n.ruleForm,rules:n.rules},{default:d((()=>[t(F,{label:"地区",prop:"area"},{default:d((()=>[t(p,{modelValue:n.ruleForm.area,"onUpdate:modelValue":a[1]||(a[1]=e=>n.ruleForm.area=e)},null,8,["modelValue"])])),_:1}),t(F,null,{default:d((()=>[t(_,{type:"primary",onClick:i.submitForm},{default:d((()=>[s])),_:1},8,["onClick"])])),_:1})])),_:1},8,["model","rules"])])),_:1})])},m.__scopeId="data-v-219cd1aa";export{m as default};
