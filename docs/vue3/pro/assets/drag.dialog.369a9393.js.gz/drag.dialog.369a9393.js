
/**
 * name: Fantastic-admin
 * homepage: https://hooray.gitee.io/fantastic-admin/
 */
    
import{r as l,ae as a,o as e,s as i,i as d,w as o,I as t,v as s,A as n}from"./vendor.5d2d2ca8.js";const u={data:()=>({dialogVisible:!1})},r=n("点击打开 Dialog"),g=s("div",null," 按住我进行拖动 ",-1),f=s("span",null,"这是一段信息",-1),p={class:"dialog-footer"},V=n("取 消"),c=n("确 定");u.render=function(n,u,b,m,v,_){const k=l("page-header"),y=l("el-button"),C=l("el-dialog"),h=l("page-main"),w=a("drag");return e(),i("div",null,[d(k,{title:"可拖动对话框"}),d(h,null,{default:o((()=>[d(y,{type:"text",onClick:u[0]||(u[0]=l=>v.dialogVisible=!0)},{default:o((()=>[r])),_:1}),t(s("div",null,[d(C,{modelValue:v.dialogVisible,"onUpdate:modelValue":u[3]||(u[3]=l=>v.dialogVisible=l),width:"30%"},{title:o((()=>[g])),footer:o((()=>[s("span",p,[d(y,{onClick:u[1]||(u[1]=l=>v.dialogVisible=!1)},{default:o((()=>[V])),_:1}),d(y,{type:"primary",onClick:u[2]||(u[2]=l=>v.dialogVisible=!1)},{default:o((()=>[c])),_:1})])])),default:o((()=>[f])),_:1},8,["modelValue"])],512),[[w]])])),_:1})])};export{u as default};
